﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetStartedDebugging
{
    internal class Program
    {
        static void Main()
        {
            char[] letters = { 'f', 'r', 'e', 'd', ' ', 's', 'm', 'i', 't', 'h' };
            string name = "";
            int[] a = new int[10];
            for (int i = 0; i < letters.Length; i++)
            {
                name += letters[i];
                a[i] = i + 1;
                SendMassage(name, a[i]);
            }
            Console.ReadKey();
        }
        static void SendMassage(string name,int msg)
        {
            Console.WriteLine("hello, " + name + "! Count to " + msg);
        }
    }
}
